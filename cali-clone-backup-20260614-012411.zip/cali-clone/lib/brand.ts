// Client-safe brand case-study content model.
// No "fs" import — this is imported by both the server page and the
// "use client" MastMasalaPage component. Edit DEFAULT_BRAND to change
// the page, or override it later via the admin dashboard (getDoc("brand", ...)).

const BASE = "https://rajeshwarichauhan.in/wp-content/uploads";

export type BrandStat = { raw: number; suffix: string; decimals: number; label: string };
export type CalRow = { type: string; date: string; concept: string; copy: string };
export type AnalyticsCard = { stat: string; label: string; sub: string; img: string };
export type GalleryImage = { src: string; alt: string };
export type ApproachItem = { num: string; title: string; body: string };
export type DeliveredCard = { video: string; title: string; body: string };

export type BrandData = {
  hero: {
    eyebrow: string;
    title: string;        // animated char-by-char title, e.g. "MAST MASALA"
    bgText: string;       // decorative background text
    tagline: string;
    tags: string[];
  };

  stats: BrandStat[];

  tabs: {
    contentLabel: string;
    socialLabel: string;
    servicingLabel: string;
  };

  workDone: {
    title: string;
    bullets: string[];
  };

  calendar: {
    title: string;
    rows: CalRow[];
  };

  analytics: AnalyticsCard[];

  mom: {
    title: string;
    bullets: string[];
  };

  gallery: {
    title: string;
    images: GalleryImage[];
  };

  story: {
    title: string;
    body: string;
    bigNum: string;
  };

  approach: {
    eyebrow: string;
    heading: string;       // may contain <em> markup
    items: ApproachItem[];
  };

  featured: {
    eyebrow: string;
    heading: string;       // may contain <em> markup
    video: string;
    glassLabel: string;
    glassText: string;
  };

  philosophy: {
    eyebrow: string;
    heading: string;       // may contain <em> markup
    video: string;
    paragraphs: string[];
  };

  delivered: {
    eyebrow: string;
    heading: string;       // may contain <em> markup
    cards: DeliveredCard[];
  };

  cta: {
    sub: string;
    label: string;
    href: string;
  };
};

export const DEFAULT_BRAND: BrandData = {
  hero: {
    eyebrow: "CLIENT ARCHIVE",
    title: "MAST MASALA",
    bgText: "MM",
    tagline: "Dash Ka Swaad",
    tags: ["Content Writing", "Social Media", "Client Servicing"],
  },

  stats: [
    { raw: 22,   suffix: "%", decimals: 0, label: "Reach Growth" },
    { raw: 29.4, suffix: "M", decimals: 1, label: "Impressions" },
    { raw: 21,   suffix: "%", decimals: 0, label: "Engagement Rate" },
    { raw: 4305, suffix: "",  decimals: 0, label: "Total Followers" },
  ],

  tabs: {
    contentLabel: "Content Writing",
    socialLabel: "Social Media",
    servicingLabel: "Client Servicing",
  },

  workDone: {
    title: "Work Done",
    bullets: [
      "Weekly reporting + action plan",
      "Execution with creatives + revisions",
      "Monthly growth strategy updates",
      "Improved turnaround + consistency",
    ],
  },

  calendar: {
    title: "Content Calendar Glimpse",
    rows: [
      { type: "Reel",   date: "1/10/2024", concept: "Diwali",                  copy: "Diwali ki roshni khushiyan ka pal…" },
      { type: "Static", date: "3/11/2024", concept: "Bhai Dooj",               copy: "Bhai ko ho khushi ke paas…" },
      { type: "Reel",   date: "6/11/2024", concept: "Rajasthani Garam Masala", copy: "Har dish ko de zeeta sting…" },
    ],
  },

  analytics: [
    { stat: "+22%", label: "Reach Growth", sub: "29.4M Impressions",    img: `${BASE}/2025/12/reach-growth-8.png` },
    { stat: "+21%", label: "Engagement",   sub: "2.1% Engagement Rate", img: `${BASE}/2025/12/engagement-8.png` },
    { stat: "+20%", label: "CTR",          sub: "214 Link Clicks",      img: `${BASE}/2025/12/ctrleft-4.png` },
    { stat: "+18%", label: "Retention",    sub: "Avg. watch time up",   img: `${BASE}/2025/12/retension-3.png` },
  ],

  mom: {
    title: "Mast Masala — Festive Content Planning",
    bullets: [
      "Festive Content Roadmap Ready",
      "Recipe & Festive Posts Finalised",
      "High-Engagement Content Plan (Reels, GIFs, interactive posts)",
      "Celebrating Culture & Traditions",
      "Clear Posting Plan Set",
      "Success Metrics Defined",
    ],
  },

  gallery: {
    title: "Creative Gallery",
    images: [
      { src: `${BASE}/2025/12/Mast-Masala_Gandhi-Jayanti.jpg`, alt: "Gandhi Jayanti post" },
      { src: `${BASE}/2025/12/mast-masala-dashera_-2.jpg`,     alt: "Dussehra post" },
      { src: `${BASE}/2025/12/Mast-Masala-Dhanteras_1.jpg`,    alt: "Dhanteras post" },
      { src: `${BASE}/2025/12/Mast-Masala-Oct-22-post.jpg`,    alt: "October post" },
      { src: `${BASE}/2025/12/Mast-Masala-Oct-21-post.jpg`,    alt: "October post 2" },
      { src: `${BASE}/2025/12/happy-makar-sankrant.jpg`,       alt: "Makar Sankranti post" },
    ],
  },

  story: {
    title: "60 Years of Legacy",
    body: "Mast Masala has a legacy of over 60 years in the field of spices. Founded by Mr. Kailash Ramanlal Jhaveri, following the legacy of his late father Shri Ramanlal J. Jhaveri from Chorwad, Junagadh, Gujarat. JSPL delivers fresh, pure, and authentic quality products through research, innovation, and technological advancements.",
    bigNum: "60",
  },

  approach: {
    eyebrow: "HOW WE WORK",
    heading: "Crafted for <em>Growth</em>",
    items: [
      { num: "01", title: "Deep Brand Audit",     body: "We begin by understanding the brand’s voice, audience, and existing content performance before we strategise." },
      { num: "02", title: "Content Architecture", body: "Every post is mapped to a goal — awareness, engagement, or conversion — and slotted into a structured monthly calendar." },
      { num: "03", title: "Execute & Iterate",    body: "We launch, track performance metrics weekly, and refine based on what the data tells us — no guesswork, only growth." },
    ],
  },

  featured: {
    eyebrow: "CAMPAIGN REEL",
    heading: "Campaigns That <em>Convert</em>",
    video: "https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260402_054547_9875cfc5-155a-4229-8ec8-b7ba7125cbf8.mp4",
    glassLabel: "Featured Work",
    glassText: "Mast Masala festive campaign — building brand recall through storytelling-led content.",
  },

  philosophy: {
    eyebrow: "OUR PHILOSOPHY",
    heading: "Strategy <em>×</em> Results",
    video: "https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260307_083826_e938b29f-a43a-41ec-a153-3d4730578ab8.mp4",
    paragraphs: [
      "Great content isn’t just creative — it’s calculated. For Mast Masala, we merged authentic cultural storytelling with data-driven posting strategies to achieve measurable growth across Instagram and Facebook.",
      "From festive reels to daily engagement posts, every deliverable was aligned with the brand’s 60-year legacy while connecting with a modern, digital-first audience.",
    ],
  },

  delivered: {
    eyebrow: "DELIVERABLES",
    heading: "What We <em>Delivered</em>",
    cards: [
      {
        video: "https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260314_131748_f2ca2a28-fed7-44c8-b9a9-bd9acdd5ec31.mp4",
        title: "Content Strategy",
        body: "Monthly calendar, 30+ posts, 6+ reels with cultural hooks and festive themes.",
      },
      {
        video: "https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260324_151826_c7188672-6e92-402c-9e45-f1e0f454bdc4.mp4",
        title: "Growth & Analytics",
        body: "+22% reach, 29.4M impressions, and +21% engagement rate in festive quarter.",
      },
    ],
  },

  cta: {
    sub: "Want results like these?",
    label: "Book a discovery call with Raji →",
    href: "/contact",
  },
};
